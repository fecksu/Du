module.exports = {
  name: "eval",
  code: `
$eval[$message;yes;yes;yes;yes]

$onlyForIDs[$botOwnerID;
	{
		"content":"Non."
	}
]
`
}