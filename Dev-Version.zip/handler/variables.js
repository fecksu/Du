module.exports = (bot) => {

//Bot Variables
  bot.variables({
    prefix: "$"
})
}